﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialThanks : MonoBehaviour {

    private bool pushFlag = false;

    [SerializeField]
    private GameObject[] STobj;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //pushFlag = false;

        if(pushFlag)
        {
            for(int i = 0; i < STobj.Length; i++)
            {
                STobj[i].SetActive(true);
            }
        }
        else
        {
            for (int i = 0; i < STobj.Length; i++)
            {
                STobj[i].SetActive(false);
            }
        }
	}

    public void ButtonPush()
    {
        pushFlag = !pushFlag;

    }
}
