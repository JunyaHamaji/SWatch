﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hugou : MonoBehaviour {

    [SerializeField]
    private SpriteRenderer[] hugou;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SpriteChange()
    {
        hugou[0].enabled = true;
        hugou[1].enabled = true;
        hugou[2].enabled = false;
    }

    public void Reset()
    {
        hugou[0].enabled = false;
        hugou[1].enabled = false;
        hugou[2].enabled = true;

    }

    public void CreateParticle()
    {
    }
}
