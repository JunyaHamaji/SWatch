﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Suika : MonoBehaviour {

    [SerializeField]
    private SpriteRenderer[] wareSuika;

    [SerializeField]
    private GameObject particle;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void SpriteChange()
    {
        wareSuika[0].enabled = true;
        wareSuika[1].enabled = true;
        wareSuika[2].enabled = false;
    }

    public void Reset()
    {
        wareSuika[0].enabled = false;
        wareSuika[1].enabled = false;
        wareSuika[2].enabled = true;

    }

    public void CreateParticle()
    {
        Instantiate(particle, transform.position, transform.rotation);
    }
}
