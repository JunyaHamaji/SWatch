﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mouse: MonoBehaviour {


    private Vector3 position;
    private Vector3 screenToWorldPointPosition;

	// Use this for initialization
	void Start () {
        // マウスの表示or非表示
        Cursor.visible = false;

        this.transform.SetAsLastSibling();
	}
	
	// Update is called once per frame
	void Update () {
        position = Input.mousePosition;
        position.z = 10f;
        position.y -= 30f;
        screenToWorldPointPosition = Camera.main.ScreenToWorldPoint(position);
        this.transform.position = screenToWorldPointPosition;
	}
}
