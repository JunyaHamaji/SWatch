﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PushCount : MonoBehaviour
{

    private int playerID = 1;
    public int pushCount_1 = 0;
    public int pushCount_2 = 0;

    private bool playFlag = false;
    private bool endFlag = false;
    private bool intervalFlag = false;

    private float time = 30f;
    private float intervalTime = 3f;

    [SerializeField]
    private Text text;
    [SerializeField]
    private Text timeText;
    [SerializeField]
    private Text buttonText;
    [SerializeField]
    private Suika suika;
    [SerializeField]
    private Hugou hugou;

    public int rand;


    // Use this for initialization
    void Start()
    {
        playerID = 1;
        pushCount_1 = 0;
        pushCount_2 = 0;
        playFlag = false;
        endFlag = false;
        intervalFlag = false;
        time = 30f;
        intervalTime = 3f;
        rand = Random.Range(0, 1);
    }

    // Update is called once per frame
    void Update()
    {

        if (playFlag)
        {
            time -= Time.deltaTime;
            timeText.text = ("Time:" + Mathf.Floor(time));
        }

        if (intervalFlag)
        {
            intervalTime -= Time.deltaTime;
            timeText.text = ("Interval:" + Mathf.Floor(intervalTime));
        }

        if (time < 0)
        {
            suika.SpriteChange();
            if (playerID < 2)
            {
                playFlag = false;
                playerID = 2;
                text.text = ("Next Player2");
                buttonText.text = ("Please Wait");
                time = 30f;
                intervalFlag = true;
            }

            else
            {
                endFlag = true;
            }
        }

        if (intervalTime < 0)
        {
            if (intervalFlag)
            {
                suika.Reset();
                //hugou.Reset();
                intervalFlag = false;
                text.text = ("Player2");
                buttonText.text = ("PushStart");
            }
        }

        if (endFlag)
        {
            text.text = ("Player1:" + pushCount_1 + "\nPlayer2:" + pushCount_2);

            if (pushCount_1 > pushCount_2)
            {
                timeText.text = ("Player1 WIN!");
            }
            else if (pushCount_1 == pushCount_2)
            {
                timeText.text = ("DRAW");
            }
            else
            {
                timeText.text = ("Player2 WIN!");
            }
        }

    }

    public void ButtonPush()
    {
        if (!playFlag && !endFlag && !intervalFlag)
        {
            playFlag = true;
            buttonText.text = ("Push!!");
        }
        else if (playFlag && !endFlag)
        {
            suika.CreateParticle();

            switch (playerID)
            {
                case 1:
                    pushCount_1++;
                    //if (pushCount_1 > 100) hugou.SpriteChange();
                    break;

                case 2:
                    pushCount_2++;
                    //if (pushCount_2 > 100) hugou.SpriteChange();
                    break;
            }
        }

    }


}
